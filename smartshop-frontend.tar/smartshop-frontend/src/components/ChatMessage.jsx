import React from 'react';
import { User, Bot, Star } from 'lucide-react';
import { cn, formatTime, parseMarkdown } from '../utils/helpers';

const ChatMessage = ({ message, onRate }) => {
  const isUser = message.role === 'user';
  const [rating, setRating] = React.useState(message.rating || 0);
  const [isRated, setIsRated] = React.useState(message.rated || false);

  const handleRate = (value) => {
    setRating(value);
    setIsRated(true);
    if (onRate) {
      onRate(value);
    }
  };

  return (
    <div
      className={cn(
        'flex gap-3 mb-4 message-enter',
        isUser ? 'flex-row-reverse' : 'flex-row'
      )}
    >
      {/* Avatar */}
      <div
        className={cn(
          'flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center',
          isUser
            ? 'bg-gradient-to-br from-primary-500 to-secondary-500'
            : 'bg-gradient-to-br from-gray-700 to-gray-900'
        )}
      >
        {isUser ? (
          <User className="w-5 h-5 text-white" />
        ) : (
          <Bot className="w-5 h-5 text-white" />
        )}
      </div>

      {/* Message Content */}
      <div
        className={cn(
          'flex-1 max-w-[75%]',
          isUser ? 'items-end' : 'items-start'
        )}
      >
        {/* Message Bubble */}
        <div
          className={cn(
            'rounded-2xl px-4 py-3 shadow-sm',
            isUser
              ? 'bg-gradient-to-r from-primary-500 to-secondary-500 text-white rounded-tr-sm'
              : 'bg-white text-gray-800 border border-gray-200 rounded-tl-sm'
          )}
        >
          {/* Text Content */}
          {message.content && (
            <div
              className="text-sm leading-relaxed whitespace-pre-wrap"
              dangerouslySetInnerHTML={{
                __html: parseMarkdown(message.content),
              }}
            />
          )}

          {/* Product Image */}
          {message.image_url && (
            <div className="mt-3">
              <img
                src={message.image_url}
                alt="Product"
                className="rounded-lg max-w-full h-auto shadow-md"
                loading="lazy"
              />
            </div>
          )}

          {/* Product Card (if structured data) */}
          {message.product && (
            <div className="mt-3 bg-white/10 backdrop-blur-sm rounded-lg p-3 border border-white/20">
              <h4 className="font-semibold text-sm mb-1">
                {message.product.name}
              </h4>
              <p className="text-xs opacity-90">
                {message.product.price} FCFA
              </p>
              {message.product.in_stock !== undefined && (
                <span
                  className={cn(
                    'inline-block mt-2 px-2 py-1 text-xs rounded-full',
                    message.product.in_stock
                      ? 'bg-green-500/20 text-green-100'
                      : 'bg-red-500/20 text-red-100'
                  )}
                >
                  {message.product.in_stock ? '✅ En stock' : '❌ Rupture'}
                </span>
              )}
            </div>
          )}
        </div>

        {/* Timestamp */}
        <div
          className={cn(
            'text-xs text-gray-500 mt-1 px-2',
            isUser ? 'text-right' : 'text-left'
          )}
        >
          {formatTime(message.timestamp)}
        </div>

        {/* Rating Component (only for agent contact messages) */}
        {message.type === 'CONTACT_AGENT' && !isUser && (
          <div className="mt-3 bg-white rounded-lg p-4 border border-gray-200 shadow-sm">
            <p className="text-sm text-gray-700 mb-2 font-medium">
              ⭐ Notez cette mise en relation
            </p>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  onClick={() => !isRated && handleRate(star)}
                  disabled={isRated}
                  className={cn(
                    'transition-all duration-200',
                    isRated && 'cursor-not-allowed opacity-50'
                  )}
                >
                  <Star
                    className={cn(
                      'w-6 h-6',
                      star <= rating
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-gray-300 hover:text-yellow-400'
                    )}
                  />
                </button>
              ))}
            </div>
            {isRated && (
              <p className="text-xs text-green-600 mt-2">
                Merci pour votre retour ! 🙏
              </p>
            )}
          </div>
        )}

        {/* Quick Reply Buttons (if present) */}
        {message.quickReplies && message.quickReplies.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-2">
            {message.quickReplies.map((reply, idx) => (
              <button
                key={idx}
                className="bg-white text-primary-600 border border-primary-200 px-3 py-1.5 rounded-full text-xs hover:bg-primary-50 transition-colors"
                onClick={() => reply.onClick && reply.onClick()}
              >
                {reply.label}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ChatMessage;
